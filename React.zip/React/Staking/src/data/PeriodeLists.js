export const periodeList  = [
    {
      label: '1 Day',
      duration:'1d',
    },
    {
      label: '1 Week',
      duration:'7d',
    },
    {
      label: '1 Month',
      duration:'30d',
    },
   
  ];
  